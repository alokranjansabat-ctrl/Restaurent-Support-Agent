# Restaurant Support & Operations Agent

A practical assessment implementation for an AI Automation & Agents Developer role.

## Features
- FastAPI chat endpoint and browser chat UI
- Three agent tools: order status, order details, support-ticket creation
- Local knowledge-base retrieval (RAG-style lexical retrieval)
- Conversation history by session ID
- Safe handling of unknown orders and unsupported knowledge
- Complaint classification and priority workflow
- Pydantic structured request/response validation
- Mock operational data; no real customer data or external APIs

## Architecture
User -> FastAPI /chat -> RestaurantAgent
                         |-> Operational tools
                         |-> Knowledge-base retrieval
                         |-> Complaint classification -> Ticket tool
                         `-> Safe fallback

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

## Example requests

```text
Where is my order ORD1001?
Show details for ORD1002.
What is your cancellation policy?
I was double charged and need urgent help.
```

## API
- GET `/health`
- POST `/chat`
- GET `/api/orders/{order_id}`
- GET `/api/orders/{order_id}/status`
- POST `/api/support/tickets`

## Testing

```bash
pytest -q
```

## Important assessment note
The operational APIs are intentionally mocked/local. The agent must not invent order status, refund decisions, or delivery times. When verified data is unavailable, it says so or escalates.

## Extension points
For a production version:
1. Replace mock order data with authenticated restaurant APIs.
2. Replace lexical retrieval with an embedding/vector store.
3. Add an LLM provider behind an explicit adapter.
4. Add authentication, rate limiting, audit logging, retries/timeouts and observability.
5. Add notification integrations for created tickets.

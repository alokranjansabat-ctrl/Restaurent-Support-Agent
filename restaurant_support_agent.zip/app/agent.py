import re
from .tools import get_order_details, get_order_status, create_support_ticket
from .rag import retrieve
from .workflow import classify

class RestaurantAgent:
    def __init__(self):
        self.sessions = {}

    def _order_id(self, message):
        m = re.search(r"\bORD\d+\b", message.upper())
        return m.group(0) if m else None

    def handle(self, message: str, session_id: str):
        history = self.sessions.setdefault(session_id, [])
        history.append({"role": "user", "content": message})

        text = message.lower()
        used = []
        sources = []
        ticket_id = None

        order_id = self._order_id(message)
        if any(x in text for x in ["order status", "where is my order", "track my order", "delivery status", "status of"]) and order_id:
            result = get_order_status(order_id)
            used.append("get_order_status")
            if not result["found"]:
                answer = f"I couldn't find {order_id}. Please verify the order ID."
            else:
                eta = result["eta_minutes"]
                eta_text = f" Estimated time: about {eta} minutes." if eta else ""
                answer = f"Order {order_id} is currently '{result['status']}'.{eta_text}"
            intent = "order_status"
        elif any(x in text for x in ["order details", "what did i order", "items in"]) and order_id:
            result = get_order_details(order_id)
            used.append("get_order_details")
            if not result["found"]:
                answer = f"I couldn't find {order_id}. Please verify the order ID."
            else:
                o = result["order"]
                answer = f"{o['order_id']}: {', '.join(o['items'])}, total ₹{o['amount']}, status {o['status']}."
            intent = "order_details"
        else:
            complaint_signals = ["complaint", "problem", "wrong", "double charged", "not received", "urgent", "support"]
            policy_question = any(x in text for x in ["policy", "rules", "how long", "what is", "can i cancel", "refund policy"])
            c = classify(message)
            if any(x in text for x in complaint_signals) and not policy_question:
                ticket = create_support_ticket(message, c.category, c.priority)
                used.append("create_support_ticket")
                ticket_id = ticket["ticket_id"]
                answer = f"I couldn't safely resolve this from the available operational data, so I created support ticket {ticket_id}. Priority: {c.priority}."
                intent = "support_escalation"
            else:
                docs = retrieve(message)
                if docs:
                    sources = [f"knowledge_base.md:{i+1}" for i, _ in enumerate(docs)]
                    answer = "Based on the restaurant policy:\n\n" + "\n\n".join(docs)
                    intent = "knowledge_base"
                else:
                    answer = "I don't have enough verified information to answer that safely. Please provide an order ID or ask about restaurant policies, delivery, cancellation, refunds, or support."
                    intent = "unknown"

        history.append({"role": "assistant", "content": answer})
        return {
            "answer": answer,
            "intent": intent,
            "used_tools": used,
            "sources": sources,
            "ticket_id": ticket_id,
        }

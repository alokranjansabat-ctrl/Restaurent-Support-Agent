from dataclasses import dataclass
import re

CATEGORIES = {
    "payment": "Payment",
    "charged": "Payment",
    "refund": "Refund",
    "cancel": "Refund",
    "order": "Order",
    "delivery": "Delivery",
    "late": "Delivery",
    "technical": "Technical",
    "app": "Technical",
    "login": "Technical",
}

@dataclass
class Classification:
    category: str
    priority: str
    sentiment: str
    reason: str

def classify(message: str) -> Classification:
    text = message.lower()
    category = "Other"
    for word, value in CATEGORIES.items():
        if word in text:
            category = value
            break

    urgent_words = ["fraud", "double charged", "stolen", "unsafe", "angry", "urgent", "not received"]
    negative_words = ["angry", "bad", "late", "wrong", "missing", "refund", "problem", "complaint"]
    priority = "High" if any(w in text for w in urgent_words) else ("Medium" if any(w in text for w in negative_words) else "Low")
    sentiment = "Negative" if any(w in text for w in negative_words) else "Neutral"
    return Classification(category, priority, sentiment, "Rule-based validation fallback")

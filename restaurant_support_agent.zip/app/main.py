from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, Literal
from .agent import RestaurantAgent
from .tools import get_order_details, get_order_status, create_support_ticket

app = FastAPI(title="Restaurant Support & Operations Agent", version="1.0.0")
agent = RestaurantAgent()

class ChatRequest(BaseModel):
    message: str = Field(min_length=1)
    session_id: str = "demo-session"

class ChatResponse(BaseModel):
    answer: str
    intent: str
    used_tools: list[str] = []
    sources: list[str] = []
    ticket_id: Optional[str] = None

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    return agent.handle(req.message, req.session_id)

@app.get("/api/orders/{order_id}")
def order_details(order_id: str):
    result = get_order_details(order_id)
    if not result["found"]:
        raise HTTPException(status_code=404, detail="Order not found")
    return result

@app.get("/api/orders/{order_id}/status")
def order_status(order_id: str):
    result = get_order_status(order_id)
    if not result["found"]:
        raise HTTPException(status_code=404, detail="Order not found")
    return result

class TicketRequest(BaseModel):
    customer_message: str
    category: Literal["Payment","Order","Delivery","Refund","Technical","Other"] = "Other"
    priority: Literal["Low","Medium","High"] = "Medium"

@app.post("/api/support/tickets")
def support_ticket(req: TicketRequest):
    return create_support_ticket(req.customer_message, req.category, req.priority)

app.mount("/", StaticFiles(directory="web", html=True), name="web")

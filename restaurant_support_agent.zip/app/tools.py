from datetime import datetime, timezone
from uuid import uuid4

ORDERS = {
    "ORD1001": {
        "order_id": "ORD1001",
        "customer": "Demo Customer",
        "items": ["Paneer Tikka", "Butter Naan"],
        "amount": 420,
        "status": "Out for delivery",
        "eta_minutes": 18,
        "restaurant": "Spice Garden",
        "delivery_partner": "Demo Rider",
    },
    "ORD1002": {
        "order_id": "ORD1002",
        "customer": "Demo Customer",
        "items": ["Veg Biryani"],
        "amount": 280,
        "status": "Preparing",
        "eta_minutes": 32,
        "restaurant": "Biryani House",
        "delivery_partner": None,
    },
    "ORD1003": {
        "order_id": "ORD1003",
        "customer": "Demo Customer",
        "items": ["Masala Dosa", "Coffee"],
        "amount": 190,
        "status": "Delivered",
        "eta_minutes": 0,
        "restaurant": "South Corner",
        "delivery_partner": "Demo Rider",
    },
}

def get_order_details(order_id: str) -> dict:
    order = ORDERS.get(order_id.upper())
    return {"found": bool(order), "order": order}

def get_order_status(order_id: str) -> dict:
    order = ORDERS.get(order_id.upper())
    if not order:
        return {"found": False, "order_id": order_id, "status": None}
    return {
        "found": True,
        "order_id": order["order_id"],
        "status": order["status"],
        "eta_minutes": order["eta_minutes"],
    }

def create_support_ticket(customer_message: str, category: str, priority: str) -> dict:
    return {
        "ticket_id": f"TKT-{uuid4().hex[:8].upper()}",
        "category": category,
        "priority": priority,
        "message": customer_message,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "created",
    }

from pathlib import Path
import re
from collections import Counter

KB_PATH = Path("data/knowledge_base.md")

def _chunks():
    text = KB_PATH.read_text(encoding="utf-8")
    return [x.strip() for x in text.split("\n\n") if x.strip()]

def _tokens(text):
    return re.findall(r"[a-z0-9]+", text.lower())

def retrieve(query: str, k: int = 3):
    q = Counter(_tokens(query))
    scored = []
    for chunk in _chunks():
        c = Counter(_tokens(chunk))
        overlap = sum(min(q[t], c[t]) for t in q)
        scored.append((overlap, chunk))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [chunk for score, chunk in scored[:k] if score > 0]

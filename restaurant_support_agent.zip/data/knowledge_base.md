# Restaurant FAQ and Policies

## Cancellation and refunds
Customers can request cancellation while an order is still in the restaurant's cancellable state. Once an order has entered preparation, cancellation may not be available. Refund decisions depend on the payment status and the reason for cancellation; the support team must verify the transaction before promising a refund.

## Delivery
Estimated delivery time is an estimate and can change because of restaurant preparation, traffic, weather, or delivery-partner availability. The agent must not invent a delivery time. It should use the operational order-status tool when an order ID is available.

## Missing or incorrect items
For missing or incorrect items, the customer should provide the order ID and describe the issue. Support may request evidence and will verify the order before deciding on a refund or replacement.

## Payments
If a customer reports a duplicate charge or an unexpected payment, do not promise a refund without transaction verification. Escalate the issue to support with high priority when the customer reports a duplicate charge or suspected fraud.

## Operating policy
Restaurant support hours are 9:00 AM to 11:00 PM IST. Questions outside the knowledge base should not be answered by guessing. The agent should clearly state when verified information is unavailable.

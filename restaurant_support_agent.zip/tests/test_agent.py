from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").json()["status"] == "ok"

def test_order_status_tool():
    r = client.post("/chat", json={"message": "Where is my order ORD1001?"})
    assert r.status_code == 200
    data = r.json()
    assert data["intent"] == "order_status"
    assert "get_order_status" in data["used_tools"]

def test_unknown_order_does_not_invent():
    r = client.post("/chat", json={"message": "Where is my order ORD9999?"})
    assert "couldn't find" in r.json()["answer"].lower()

def test_escalation():
    r = client.post("/chat", json={"message": "I was double charged, this is urgent"})
    data = r.json()
    assert data["intent"] == "support_escalation"
    assert data["ticket_id"]

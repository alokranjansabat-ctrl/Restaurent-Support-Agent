# Architecture Notes

## Components
1. **FastAPI** exposes the chat and mock operational APIs.
2. **RestaurantAgent** routes requests based on intent and available verified data.
3. **Tools** are isolated functions for operational data and ticket creation.
4. **RAG layer** retrieves relevant policy chunks from `data/knowledge_base.md`.
5. **Workflow layer** classifies complaints and assigns priority.
6. **Pydantic schemas** validate API input and output.

## Reliability decisions
- Order information comes only from the order tool.
- Unknown order IDs are never filled with guessed values.
- Policy answers are grounded in retrieved knowledge-base text.
- Missing policy information produces an explicit safe fallback.
- Complaints that cannot be resolved are escalated into a structured ticket.
- Mock data is clearly separated from the agent logic.

## Production evolution
Use an LLM adapter to classify intent and generate natural-language responses, but keep operational facts tool-grounded. Use a vector database for semantic retrieval, add authentication and per-user authorization, and wrap external tools with timeout/retry/circuit-breaker policies.

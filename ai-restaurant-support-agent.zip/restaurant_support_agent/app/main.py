import logging
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.config import settings
from app.schemas import ChatRequest, ChatResponse
from app.services.agent import handle_chat
from app.services.store import get_order
from app.tools.order_tools import validate_order_id, get_order_details, get_order_status
from app.tools.ticket_tools import create_support_ticket
from app.services.classifier import classify_complaint

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO),
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")

app = FastAPI(title=settings.app_name, version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def home():
    return FileResponse("static/index.html")

@app.get("/health")
def health():
    return {"status": "ok", "service": settings.app_name}

@app.get("/api/orders/{order_id}")
def order_details(order_id: str):
    try:
        return get_order_details(order_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/orders/{order_id}/status")
def order_status(order_id: str):
    try:
        return get_order_status(order_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/support/tickets")
def support_ticket(payload: dict):
    try:
        classification = classify_complaint(payload.get("summary", "Support request"))
        return create_support_ticket(classification, payload.get("customer_id"), payload.get("order_id"))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/agent/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    answer, sources, calls, ticket = handle_chat(
        request.session_id, request.message, request.customer_id
    )
    return ChatResponse(session_id=request.session_id, answer=answer,
                        sources=sources, tool_calls=calls, ticket=ticket)

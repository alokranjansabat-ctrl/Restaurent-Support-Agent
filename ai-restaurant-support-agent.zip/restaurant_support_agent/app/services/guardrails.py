import re

INJECTION_PATTERNS = [
    r"ignore (all|any|previous) instructions",
    r"show me every customer",
    r"show .*api key",
    r"reveal .*system prompt",
    r"give me .*credentials",
    r"dump .*database",
    r"execute .*sql",
    r"run .*shell",
]

def is_unsafe_request(message: str) -> bool:
    m = message.lower()
    return any(re.search(p, m) for p in INJECTION_PATTERNS)

def extract_order_id(message: str):
    m = re.search(r"\bORD-[0-9]{4}\b", message.upper())
    return m.group(0) if m else None

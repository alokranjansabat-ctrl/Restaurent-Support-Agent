from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class KnowledgeBase:
    def __init__(self, path="data/knowledge_base.txt"):
        self.path = Path(path)
        self.documents = []
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.matrix = None
        self.load()

    def load(self):
        text = self.path.read_text(encoding="utf-8")
        blocks = [b.strip() for b in text.split("\n---\n") if b.strip()]
        self.documents = []
        for block in blocks:
            lines = block.splitlines()
            title = lines[0].strip()
            body = "\n".join(lines[1:]).strip()
            self.documents.append({"title": title, "text": body})
        self.matrix = self.vectorizer.fit_transform([d["text"] for d in self.documents])

    def search(self, query: str, top_k=3, threshold=0.12):
        q = self.vectorizer.transform([query])
        scores = cosine_similarity(q, self.matrix)[0]
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        results = []
        for idx, score in ranked[:top_k]:
            if score >= threshold:
                results.append({**self.documents[idx], "score": float(score)})
        return results

kb = KnowledgeBase()

import logging
from app.services.guardrails import is_unsafe_request, extract_order_id
from app.services.rag import kb
from app.services.classifier import classify_complaint
from app.tools.order_tools import get_order_status, get_order_details
from app.tools.ticket_tools import create_support_ticket
from app.services.store import add_message, session_messages

logger = logging.getLogger("agent")

def handle_chat(session_id: str, message: str, customer_id=None):
    add_message(session_id, "user", message)
    calls = []

    if is_unsafe_request(message):
        answer = "I can help with your own order or support request, but I cannot provide unrelated customer data, credentials, system prompts, or internal secrets."
        add_message(session_id, "assistant", answer)
        return answer, [], calls, None

    order_id = extract_order_id(message)
    lower = message.lower()

    # Operational facts always come from tools, never from the LLM.
    if order_id and any(k in lower for k in ["where", "status", "track", "arrive", "delivery"]):
        result = get_order_status(order_id)
        calls.append({"tool": "get_order_status", "success": result["ok"]})
        if result["ok"]:
            eta = f" Estimated arrival: {result['eta']}." if result.get("eta") else ""
            answer = f"Order {order_id} is currently **{result['status']}**.{eta}"
        else:
            answer = result["message"]
        add_message(session_id, "assistant", answer)
        return answer, [], calls, None

    if order_id and any(k in lower for k in ["details", "items", "what did i order", "total"]):
        result = get_order_details(order_id)
        calls.append({"tool": "get_order_details", "success": result["ok"]})
        if result["ok"]:
            o = result["order"]
            answer = f"Order {order_id}: {', '.join(o['items'])}. Total ₹{o['total']}. Payment: {o['payment_status']}."
        else:
            answer = result["message"]
        add_message(session_id, "assistant", answer)
        return answer, [], calls, None

    # Complaint automation.
    complaint_words = ["failed", "charged", "deducted", "complaint", "problem", "wrong", "refund", "not received"]
    if any(k in lower for k in complaint_words):
        classification = classify_complaint(message)
        ticket = None
        if classification.should_escalate:
            ticket = create_support_ticket(classification, customer_id=customer_id, order_id=order_id)
            calls.append({"tool": "create_support_ticket", "success": True, "ticket_id": ticket.ticket_id})
            answer = f"I've escalated this to support. Ticket **{ticket.ticket_id}** was created with {ticket.priority.value} priority."
        else:
            answer = f"I've classified this as a {classification.category.value} issue with {classification.priority.value} priority. I can help troubleshoot it."
        add_message(session_id, "assistant", answer)
        return answer, [], calls, ticket

    # RAG for policy/FAQ questions.
    results = kb.search(message)
    if results:
        best = results[0]
        answer = f"According to our policy **{best['title']}**: {best['text']}"
        sources = [r["title"] for r in results]
        add_message(session_id, "assistant", answer)
        return answer, sources, calls, None

    answer = "I don't have enough verified information in the restaurant knowledge base to answer that safely. Please contact support or provide more details."
    add_message(session_id, "assistant", answer)
    return answer, [], calls, None

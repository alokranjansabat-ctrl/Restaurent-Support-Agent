import re
from app.schemas import Category, Priority, TicketClassification

def classify_complaint(message: str) -> TicketClassification:
    m = message.lower()
    if any(x in m for x in ["payment", "charged", "deducted", "transaction"]):
        category = Category.payment
    elif any(x in m for x in ["refund", "money back", "reimburse"]):
        category = Category.refund
    elif any(x in m for x in ["delivery", "late", "rider", "arrive"]):
        category = Category.delivery
    elif any(x in m for x in ["order", "cancel", "food", "restaurant"]):
        category = Category.order
    elif any(x in m for x in ["app", "login", "website", "technical", "error"]):
        category = Category.technical
    else:
        category = Category.general

    very_negative = any(x in m for x in ["fraud", "stolen", "scam", "charged twice", "urgent"])
    negative = any(x in m for x in ["failed", "wrong", "missing", "bad", "problem", "complaint", "not received"])
    sentiment = "Very Negative" if very_negative else ("Negative" if negative else "Neutral")

    priority = Priority.high if very_negative else (Priority.medium if negative else Priority.low)
    should_escalate = category in {Category.payment, Category.refund} and negative or very_negative

    summary = re.sub(r"\s+", " ", message).strip()
    return TicketClassification(
        category=category,
        priority=priority,
        sentiment=sentiment,
        summary=summary[:500],
        should_escalate=should_escalate,
        confidence=0.88 if category != Category.general else 0.55,
    )

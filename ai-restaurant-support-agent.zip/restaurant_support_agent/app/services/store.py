from typing import Dict, List, Optional
from app.schemas import Order, SupportTicket

ORDERS: Dict[str, Order] = {
    "ORD-1001": Order(order_id="ORD-1001", customer_id="CUST-001", restaurant="Spice Garden",
                      items=["Paneer Biryani", "Lassi"], total=320, status="Delivered",
                      eta=None, payment_status="Paid"),
    "ORD-1005": Order(order_id="ORD-1005", customer_id="CUST-002", restaurant="Momo Hub",
                      items=["Veg Momos", "Cold Coffee"], total=240, status="Out for delivery",
                      eta="25 minutes", payment_status="Paid"),
    "ORD-1010": Order(order_id="ORD-1010", customer_id="CUST-003", restaurant="Dosa Point",
                      items=["Masala Dosa"], total=160, status="Failed",
                      eta=None, payment_status="Paid"),
}
TICKETS: Dict[str, SupportTicket] = {}
SESSIONS: Dict[str, List[dict]] = {}

def get_order(order_id: str) -> Optional[Order]:
    return ORDERS.get(order_id.upper())

def add_ticket(ticket: SupportTicket):
    TICKETS[ticket.ticket_id] = ticket
    return ticket

def get_ticket(ticket_id: str):
    return TICKETS.get(ticket_id)

def session_messages(session_id: str) -> List[dict]:
    return SESSIONS.setdefault(session_id, [])

def add_message(session_id: str, role: str, content: str):
    session_messages(session_id).append({"role": role, "content": content})

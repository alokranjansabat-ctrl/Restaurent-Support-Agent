from enum import Enum
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Dict, Any

class Category(str, Enum):
    payment = "Payment"
    order = "Order"
    delivery = "Delivery"
    refund = "Refund"
    technical = "Technical"
    general = "General"

class Priority(str, Enum):
    low = "Low"
    medium = "Medium"
    high = "High"

class OrderStatus(str, Enum):
    placed = "Placed"
    accepted = "Accepted"
    preparing = "Preparing"
    out_for_delivery = "Out for delivery"
    delivered = "Delivered"
    cancelled = "Cancelled"
    failed = "Failed"

class Order(BaseModel):
    order_id: str
    customer_id: str
    restaurant: str
    items: List[str]
    total: float
    status: OrderStatus
    eta: Optional[str] = None
    payment_status: str

class SupportTicket(BaseModel):
    ticket_id: str
    category: Category
    priority: Priority
    summary: str
    customer_id: Optional[str] = None
    order_id: Optional[str] = None
    source: str = "agent"
    status: str = "Open"

class TicketClassification(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    category: Category
    priority: Priority
    sentiment: str = Field(pattern="^(Positive|Neutral|Negative|Very Negative)$")
    summary: str = Field(min_length=5, max_length=500)
    should_escalate: bool
    confidence: float = Field(ge=0, le=1)

class ChatRequest(BaseModel):
    session_id: str = Field(min_length=3, max_length=100)
    message: str = Field(min_length=1, max_length=2000)
    customer_id: Optional[str] = Field(default=None, max_length=100)

class ChatResponse(BaseModel):
    session_id: str
    answer: str
    sources: List[str] = []
    tool_calls: List[Dict[str, Any]] = []
    ticket: Optional[SupportTicket] = None

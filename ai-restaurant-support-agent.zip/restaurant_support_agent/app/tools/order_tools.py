import re
from app.services.store import get_order

ORDER_ID_RE = re.compile(r"^ORD-[0-9]{4}$")

def validate_order_id(order_id: str) -> str:
    order_id = order_id.strip().upper()
    if not ORDER_ID_RE.fullmatch(order_id):
        raise ValueError("Invalid order ID format. Expected ORD-1234.")
    return order_id

def get_order_status(order_id: str):
    oid = validate_order_id(order_id)
    order = get_order(oid)
    if not order:
        return {"ok": False, "error": "ORDER_NOT_FOUND", "message": "No order was found for that ID."}
    return {"ok": True, "order_id": oid, "status": order.status.value, "eta": order.eta}

def get_order_details(order_id: str):
    oid = validate_order_id(order_id)
    order = get_order(oid)
    if not order:
        return {"ok": False, "error": "ORDER_NOT_FOUND", "message": "No order was found for that ID."}
    return {"ok": True, "order": order.model_dump()}

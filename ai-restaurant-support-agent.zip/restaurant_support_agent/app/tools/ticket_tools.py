import hashlib
from app.schemas import SupportTicket, TicketClassification
from app.services.store import add_ticket, TICKETS

def create_support_ticket(classification: TicketClassification, customer_id=None, order_id=None):
    # Deterministic idempotency key prevents duplicate tickets on retries.
    raw = f"{customer_id}|{order_id}|{classification.category}|{classification.summary}".lower()
    ticket_id = "TCK-" + hashlib.sha256(raw.encode()).hexdigest()[:8].upper()
    if ticket_id in TICKETS:
        return TICKETS[ticket_id]

    ticket = SupportTicket(
        ticket_id=ticket_id,
        category=classification.category,
        priority=classification.priority,
        summary=classification.summary,
        customer_id=customer_id,
        order_id=order_id,
    )
    return add_ticket(ticket)

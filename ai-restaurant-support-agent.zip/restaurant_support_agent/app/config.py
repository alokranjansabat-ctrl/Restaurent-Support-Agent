from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "Restaurant Support & Operations Agent"
    environment: str = "development"
    log_level: str = "INFO"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    max_tool_calls: int = 4

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
